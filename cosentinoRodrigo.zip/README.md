# juegoPreguntasRespuestas

la partida es infinita hasta que se equivoca una
agregar tabla respuestas posibles
rol usuario